package jspart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JspartApplicationTests {

	@Test
	void contextLoads() {
	}

}
